﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using BenXApp.Models;

namespace BenXApp.Controllers
{
    public class ItemCheckController : Controller
    {
        // GET: ItemCheck
        public string constring = "server=TAFT-CL729;Database=BenX;uid=sa;pwd=benilde";


        public ActionResult GoToItem()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }



            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT CommentID, a.UserID, " +
                "ItemID, FName, LName, DaComment " +
                "FROM Comments a INNER JOIN Users b " +
                "ON a.UserID = b.UserID WHERE a.ItemID = @a " +
                "ORDER BY CommentID DESC", con);
            com.Parameters.AddWithValue("@a", Session["ItemChosen"].ToString());
            SqlDataReader dr = com.ExecuteReader();
            List<Comments> list = new List<Comments>();
            while (dr.Read() == true)
            {
                Comments c = new Comments();
                c.CommentID = (int)dr[0];
                c.UserID = (int)dr[1];
                c.ItemID = (int)dr[2];
                c.Fname = dr[3].ToString();
                c.Lname = dr[4].ToString();
                c.DaComment = dr[5].ToString();
                list.Add(c);
            }
            con.Close();
            ViewData["Commenter"] = list;


            con = new SqlConnection(constring);
            con.Open();
            com = new SqlCommand("SELECT * FROM BenXItem WHERE ItemID = @a", con);
            com.Parameters.AddWithValue("@a", Session["ItemChosen"].ToString());
            dr = com.ExecuteReader();
            BenXItemModel b = new BenXItemModel();
            if (dr.Read() == true)
            {

                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();
            }
            ViewData["ItemInfo"] = b;
            con.Close();
            return View();
        }
        [HttpPost]
        public ActionResult GoToItem(FormCollection form)
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }


            Session["ItemChosen"] = form["ItemID"].ToString();
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT CommentID, a.UserID, " +
                "ItemID, FName, LName, DaComment " +
                "FROM Comments a INNER JOIN Users b " +
                "ON a.UserID = b.UserID WHERE a.ItemID = @a " +
                "ORDER BY CommentID DESC", con);
            com.Parameters.AddWithValue("@a", form["ItemID"].ToString());
            SqlDataReader dr = com.ExecuteReader();
            List<Comments> list = new List<Comments>();
            while(dr.Read()==true)
            {
                Comments c = new Comments();
                c.CommentID = (int)dr[0];
                c.UserID = (int)dr[1];
                c.ItemID = (int)dr[2];
                c.Fname = dr[3].ToString();
                c.Lname = dr[4].ToString();
                c.DaComment = dr[5].ToString();
                list.Add(c);
            }
            con.Close();
            ViewData["Commenter"] = list;


            con = new SqlConnection(constring);
            con.Open();
            com = new SqlCommand("SELECT * FROM BenXItem WHERE ItemID = @a", con);
            com.Parameters.AddWithValue("@a", form["ItemID"].ToString());
            dr = com.ExecuteReader();
            BenXItemModel b = new BenXItemModel();
            if (dr.Read() == true)
            {

                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();
            }
            ViewData["ItemInfo"] = b;
            con.Close();
            return View();
        }

        [HttpPost]
        public ActionResult Commento(FormCollection form)
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("INSERT INTO Comments VALUES " +
                "(@a,@b,@c)",con);
            com.Parameters.AddWithValue("@a", Session["Username"].ToString());
            com.Parameters.AddWithValue("@b", form["ItemID"].ToString());
            com.Parameters.AddWithValue("@c", form["Comments"].ToString());
            com.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("../ItemCheck/GotoItem");
        }

        public ActionResult BoughtPage()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            return View();
        }
        [HttpPost]
        public ActionResult BuyItem(FormCollection f)
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("UPDATE BenXItem SET ItemStatus = " +
                "'not available' WHERE ItemID = @a",con);
            com.Parameters.AddWithValue("@a", f["ItemID"].ToString());
            com.ExecuteNonQuery();

            com = new SqlCommand("INSERT INTO Purchases VALUES (@a,GETDATE(),@b,@c,@d)",con);
            com.Parameters.AddWithValue("@a", Session["Username"].ToString());
            com.Parameters.AddWithValue("@b", "1111");
            com.Parameters.AddWithValue("@c", "Recieved");
            com.Parameters.AddWithValue("@d", f["ItemID"].ToString());
            com.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("../ItemCheck/BoughtPage");
        }
        [HttpPost]
        public ActionResult RelatedItem(FormCollection f)
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM " +
                " BenXItem WHERE (ItemName LIKE '%'+@a+'%' OR " +
                " ItemDesc LIKE '%'+@a+'%' OR MajorCat LIKE '%'+@a+'%' " +
                " OR MinorTag LIKE '%'+@a+'%') " +
                "AND ItemStatus = 'available' ORDER BY ItemID DESC", con);
            com.Parameters.AddWithValue("@a", f["DaWord"].ToString());
            SqlDataReader dr = com.ExecuteReader();
            List<BenXItemModel> list = new List<BenXItemModel>();
            while (dr.Read() == true)
            {
                BenXItemModel b = new BenXItemModel();
                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();

                list.Add(b);
            }
            con.Close();
            return View(list);
        }

        public ActionResult CheckPurchase()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT PurchaseID, " +
                "a.UserID, DatePurchased, Status, a.ItemID, " +
                "ItemName FROM Purchases a INNER JOIN" +
                " BenXItem b ON a.ItemID = b.ItemID " +
                "WHERE a.UserID = @a " +
                "ORDER BY PurchaseID DESC", con);
            com.Parameters.AddWithValue("@a", Session["Username"].ToString());
            SqlDataReader dr = com.ExecuteReader();
            List<Purchases> list = new List<Purchases>();
            while(dr.Read()==true)
            {
                Purchases p = new Purchases();
                p.PurchaseID = (int)dr[0];
                p.UserID = (int)dr[1];
                p.DatePurchased = Convert.ToDateTime(dr[2]);
                p.Status = dr[3].ToString();
                p.ItemID = (int)dr[4];
                p.ItemName = dr[5].ToString();

                list.Add(p);
            }
            con.Close();
            return View(list);

        }
    }
}