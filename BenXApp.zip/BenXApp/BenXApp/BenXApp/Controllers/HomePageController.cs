﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using BenXApp.Models;

namespace BenXApp.Controllers
{
    public class HomePageController : Controller
    {
        // GET: HomePage
        public string constring = "server=TAFT-CL729;Database=BenX;uid=sa;pwd=benilde";
        public ActionResult Home()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT TOP(4) * FROM BenXItem WHERE ItemStatus = 'available' ORDER BY ItemID DESC", con);
            SqlDataReader dr = com.ExecuteReader();
            List<BenXItemModel> list = new List<BenXItemModel>();
            while (dr.Read() == true)
            {
                BenXItemModel b = new BenXItemModel();
                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();

                list.Add(b);
            }
            con.Close();
            return View(list);
        }

        public ActionResult PostItem()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            return View();
        }
        [HttpPost]
        public ActionResult PostItem(FormCollection form, HttpPostedFileBase ItemPic)
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("INSERT INTO BenXItem VALUES(@a,@b,@c,@d,@e,@f,@g,@h,'available');", con);
            com.Parameters.AddWithValue("@a", Session["Username"].ToString());
            com.Parameters.AddWithValue("@b", form["ItemName"].ToString());
            com.Parameters.AddWithValue("@c", form["ItemDesc"].ToString());
            com.Parameters.AddWithValue("@d", form["itemCond"].ToString());
            com.Parameters.AddWithValue("@e", form["MajorCat"].ToString());
            com.Parameters.AddWithValue("@f", form["MinorTag"].ToString());
            com.Parameters.AddWithValue("@g", form["ItemPrice"].ToString());
            string filename = DateTime.Now.ToString("yyyyMMddHHmmss") + ItemPic.FileName;
            com.Parameters.AddWithValue("@h", filename);
            ItemPic.SaveAs(Server.MapPath("~/Images/" + filename));
            com.ExecuteNonQuery();
            con.Close();
            
            return View();
        }

        public ActionResult ViewAllProducts()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM BenXItem WHERE ItemStatus = 'available' ORDER BY ItemID DESC", con);
            SqlDataReader dr = com.ExecuteReader();
            List<BenXItemModel> list = new List<BenXItemModel>();
            while (dr.Read() == true)
            {
                BenXItemModel b = new BenXItemModel();
                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();

                list.Add(b);
            }
            con.Close();
            return View(list);
        }
        public ActionResult ViewFashion()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM BenXItem WHERE MajorCat='fashion' AND ItemStatus = 'available' ORDER BY ItemID DESC", con);
            SqlDataReader dr = com.ExecuteReader();
            List<BenXItemModel> list = new List<BenXItemModel>();
            while (dr.Read() == true)
            {
                BenXItemModel b = new BenXItemModel();
                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();

                list.Add(b);
            }
            con.Close();
            return View(list);
        }

        public ActionResult ViewElec()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM BenXItem WHERE MajorCat='electronics and mobile' AND ItemStatus = 'available' ORDER BY ItemID DESC", con);
            SqlDataReader dr = com.ExecuteReader();
            List<BenXItemModel> list = new List<BenXItemModel>();
            while (dr.Read() == true)
            {
                BenXItemModel b = new BenXItemModel();
                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();

                list.Add(b);
            }
            con.Close();
            return View(list);
        }
        public ActionResult ViewHobbies()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM BenXItem WHERE MajorCat='hobbies and games' AND ItemStatus = 'available' ORDER BY ItemID DESC", con);
            SqlDataReader dr = com.ExecuteReader();
            List<BenXItemModel> list = new List<BenXItemModel>();
            while (dr.Read() == true)
            {
                BenXItemModel b = new BenXItemModel();
                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();

                list.Add(b);
            }
            con.Close();
            return View(list);
        }

        public ActionResult ViewMisc()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM BenXItem WHERE MajorCat='miscellaneous' AND ItemStatus = 'available' ORDER BY ItemID DESC", con);
            SqlDataReader dr = com.ExecuteReader();
            List<BenXItemModel> list = new List<BenXItemModel>();
            while (dr.Read() == true)
            {
                BenXItemModel b = new BenXItemModel();
                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();

                list.Add(b);
            }
            con.Close();
            
            return View(list);
        }
    }
}