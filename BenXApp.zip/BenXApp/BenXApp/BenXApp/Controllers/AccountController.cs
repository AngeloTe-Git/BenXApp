﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using BenXApp.Models;

namespace BenXApp.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public string constring = "server=TAFT-CL729;Database=BenX;uid=sa;pwd=benilde";
        public ActionResult SignIn()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignIn(FormCollection f)
        {

            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM Users WHERE " +
                "UserID = @a AND Password = @b",con);
            com.Parameters.AddWithValue("@a", f["Username"].ToString());
            com.Parameters.AddWithValue("@b", f["Password"].ToString());
            SqlDataReader dr = com.ExecuteReader();
            if(dr.Read()==true)
            {
                
                Session["Username"] = dr[0].ToString();
                con.Close();
                return RedirectToAction("../HomePage/Home");
                
            }
            else
            {
                con.Close();
                return RedirectToAction("../Account/SignIn");
            }
        }
        public ActionResult Exists()
        {
            return View();
        }
        public ActionResult Finish()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateAccount(FormCollection f)
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            try
            {
                SqlCommand com = new SqlCommand("INSERT INTO Users VALUES " +
                    "(@a,@b,@c,@d,@e,@f)", con);
                com.Parameters.AddWithValue("@a", f["UserID"].ToString());
                com.Parameters.AddWithValue("@b", f["FName"].ToString());
                com.Parameters.AddWithValue("@c", f["LName"].ToString());
                com.Parameters.AddWithValue("@d", f["ContactNo"].ToString());
                com.Parameters.AddWithValue("@e", f["Email"].ToString());
                com.Parameters.AddWithValue("@f", f["Password"].ToString());
                com.ExecuteNonQuery();
            }
            catch(SqlException e)
            {
                return RedirectToAction("../Account/Exists");
            }
            finally
            {
                con.Close();
                
            }
            return RedirectToAction("../Account/Finish");

        }
        public ActionResult SignOut()
        {
            Session.RemoveAll();
            return RedirectToAction("../Account/SignIn");
        }

        public ActionResult ViewAccount()
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM Users WHERE " +
                "UserID = @a",con);
            com.Parameters.AddWithValue("@a",Session["Username"].ToString());
            SqlDataReader dr = com.ExecuteReader();
            Users u = new Users();
            if(dr.Read()==true)
            {
                u.UserID = (int)dr[0];
                u.FName = dr[1].ToString();
                u.LName = dr[2].ToString();
                u.Contact = dr[3].ToString();
                u.Email = dr[4].ToString();
                u.Password = dr[5].ToString();

            }

            con.Close();

            return View(u);
        }

        public ActionResult RateUser()
        {

            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM Users WHERE " +
                "UserID = @a", con);
            com.Parameters.AddWithValue("@a", Session["UserRated"].ToString());
            SqlDataReader dr = com.ExecuteReader();
            Users u = new Users();
            if (dr.Read() == true)
            {
                u.UserID = (int)dr[0];
                u.FName = dr[1].ToString();
                u.LName = dr[2].ToString();
                u.Contact = dr[3].ToString();
                u.Email = dr[4].ToString();
            }

            con.Close();

            int TotalRatings = 0;
            int RateAve = 0;
            con = new SqlConnection(constring);
            con.Open();
            com = new SqlCommand("SELECT * FROM Ratings WHERE " +
                "UserID = @a", con);
            com.Parameters.AddWithValue("@a", Session["UserRated"].ToString());
            dr = com.ExecuteReader();
            List<Ratings> list = new List<Ratings>();
            while (dr.Read() == true)
            {
                Ratings r = new Ratings();
                r.RatingID = (int)dr[0];
                r.UserID = (int)dr[1];
                r.Rating = (int)dr[2];
                r.Comment = dr[3].ToString();

                TotalRatings = TotalRatings + r.Rating;
                RateAve = RateAve + 1;
                list.Add(r);

            }
            RateAve = (TotalRatings / RateAve);

            con.Close();
            ViewData["UserAve"] = RateAve;
            ViewData["RaterList"] = list;
            ViewData["Profile"] = u;

            return View();
        }

        [HttpPost]
        public ActionResult RateUser(FormCollection form)
        {

            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM Users WHERE " +
                "UserID = @a", con);
            com.Parameters.AddWithValue("@a", form["UserID"].ToString());
            SqlDataReader dr = com.ExecuteReader();
            Users u = new Users();
            if (dr.Read() == true)
            {
                u.UserID = (int)dr[0];
                u.FName = dr[1].ToString();
                u.LName = dr[2].ToString();
                u.Contact = dr[3].ToString();
                u.Email = dr[4].ToString();
            }

            con.Close();

            int TotalRatings = 0;
            int RateAve = 0;
            con = new SqlConnection(constring);
            con.Open();
            com = new SqlCommand("SELECT * FROM Ratings WHERE " +
                "UserID = @a", con);
            com.Parameters.AddWithValue("@a", form["UserID"].ToString());
            dr = com.ExecuteReader();
            List<Ratings> list = new List<Ratings>();
            while (dr.Read() == true)
            {
                Ratings r = new Ratings();
                r.RatingID = (int)dr[0];
                r.UserID = (int)dr[1];
                r.Rating = (int)dr[2];
                r.Comment = dr[3].ToString();

                TotalRatings = TotalRatings + r.Rating;
                RateAve = RateAve + 1;
                list.Add(r);

            }
            if(RateAve != 0)
            {
                RateAve = (TotalRatings / RateAve);
            }

            con.Close();
            ViewData["UserAve"] = RateAve;
            ViewData["RaterList"] = list;
            ViewData["Profile"] = u;

            return View();
        }
        [HttpPost]
        public ActionResult AddRating(FormCollection form)
        {
            if (string.IsNullOrEmpty(Session["Username"] as string))
            {
                return RedirectToAction("../Account/SignIn");
            }
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("INSERT INTO Ratings VALUES (@a, @b, @c)", con);
            com.Parameters.AddWithValue("@a", form["UserID"].ToString());
            com.Parameters.AddWithValue("@b", form["RateNumber"].ToString());
            com.Parameters.AddWithValue("@c", form["Comments"].ToString());
            com.ExecuteNonQuery();
            con.Close();
            Session["UserRated"] = form["UserID"].ToString();
            return RedirectToAction("../Account/RateUser");

        }
    }
}