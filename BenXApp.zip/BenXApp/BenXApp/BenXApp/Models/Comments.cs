﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace BenXApp.Models
{
    public class Comments
    {
        public string constring = "server=TAFT-CL729;Database=BenX;uid=sa;pwd=benilde";
        public int CommentID { get; set; }
        public int UserID { get; set; }
        public int ItemID { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string DaComment { get; set; }
        

    }
}