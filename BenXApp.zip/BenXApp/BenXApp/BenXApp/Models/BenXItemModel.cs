﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace BenXApp.Models
{
    public class BenXItemModel
    {
        public string constring = "server=TAFT-CL729;Database=BenX;uid=sa;pwd=benilde";
        [Key]
        public int ItemID { get; set; }
        public int UserID { get; set; }
        public string ItemName { get; set; }
        public string ItemDesc { get; set; }
        public string ItemCond { get; set; }
        public string MajorCat { get; set; }
        public string MinorTag { get; set; }
        public double ItemPrice { get; set; }
        public string ItemPic { get; set; }
        public string ItemStatus { get; set; }
        public List<BenXItemModel> BenXItems { get; set; }
        public BenXItemModel BenXItem { get; set; }

        public List<BenXItemModel> GetAllItems()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand com = new SqlCommand("SELECT * FROM BenXItem ORDER BY ItemID DESC", con);
            SqlDataReader dr = com.ExecuteReader();
            List<BenXItemModel> list = new List<BenXItemModel>();
            while(dr.Read()==true)
            {
                BenXItemModel b = new BenXItemModel();
                b.ItemID = (int)dr[0];
                b.UserID = (int)dr[1];
                b.ItemName = dr[2].ToString();
                b.ItemDesc = dr[3].ToString();
                b.ItemCond = dr[4].ToString();
                b.MajorCat = dr[5].ToString();
                b.MinorTag = dr[6].ToString();
                b.ItemPrice = Convert.ToDouble(dr[7]);
                b.ItemPic = dr[8].ToString();
                b.ItemStatus = dr[9].ToString();

                list.Add(b);
            }
            con.Close();

            return list;
        }
    }
}