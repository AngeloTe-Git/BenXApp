﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;

namespace BenXApp.Models
{
    public class Purchases
    {
        public string constring = "server=TAFT-CL729;Database=BenX;uid=sa;pwd=benilde";
        public int PurchaseID { get; set; }
        public int UserID { get; set; }
        public DateTime DatePurchased { get; set; }
        public string Status { get; set; }
        public int ItemID { get; set; }
        public string ItemName { get; set; }
        
        


    }
}